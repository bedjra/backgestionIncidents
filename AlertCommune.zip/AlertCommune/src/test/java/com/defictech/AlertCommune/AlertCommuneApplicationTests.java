package com.defictech.AlertCommune;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AlertCommuneApplicationTests {

	@Test
	void contextLoads() {
	}

}
